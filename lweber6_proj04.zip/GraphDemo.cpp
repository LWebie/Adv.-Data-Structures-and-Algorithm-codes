/**
 * A test bed for ADT member functions and non-ADT functions of a  
 * weighted digraph and implementations of basic classical graph 
 * algorithms.
 * @author Duncan, Landon Weber
 * @since 04-20-2018
 * @course: CSC3102.01
 * @see Graph.h, City.h
 */

#include <iostream>
#include <cstring>
#include <cstdlib>
#include <stdexcept>
#include <fstream>
#include <limits>
#include <iomanip>
#include <string>
#include <queue>
#include <functional>
#include <vector>
#include <algorithm>
#include <list>
#include "City.h"
#include "Graph.h"
#include "Graph.cpp"

using namespace std;

#define INFINITY numeric_limits<double>::max()

/* function prototypes */
void display(const City& c);
void readGraph(Graph<City>& newGraph, string filename);
int menu();
void floyd(const Graph<City>& g, double**& dist, int**& path);
int getComponents(const Graph<City>& g, int*& component);
bool topSortInDeg(const Graph<City> &g, int*& linearOrder);
double  primMST(const Graph<City>& g, int root, int* parent) throw (GraphException);
string trim(string text);

int main(int argc, char **argv)
{
   if (argc != 2)
   {
      cout<<"Usage: GraphDemo <filename>"<<endl;
      exit(1);
   }
   Graph<City> g;
   City aCity1, aCity2;
   int menuReturnValue, i, j,k;   
   int* top;  //parameter to topSortInDeg
   readGraph(g,argv[1]);
   long s = g.size();
   menuReturnValue = -1;
   while (menuReturnValue != 0)
   {
      menuReturnValue = menu();
      switch(menuReturnValue)
      {
          case 1: //Incidence Matrix
          {
             cout<<endl;
             cout<<"Incidence Matrix for the Unweighted Directed Graph In "<<argv[1]<<endl;
             cout<<endl;
             //Begin Code: Add code here to generate the incidence matrix of an unweighted digraph
             int incidenceMatrix[s][g.countEdges()]; //matrix of vertex total X edges total
              memset(incidenceMatrix,0, sizeof(incidenceMatrix)); //fill a block of memory w.r.t incidence matrix and its size
              int edgeNum = 0; 
              for(int i = 0; i < s; i++) //loop through each vertex and edge
              {
                  for(int j = 0; j < s; j++)
                  {
                      if(g.isEdge(g.retrieveVertex(City(i+1)),g.retrieveVertex(City(j+1)))) //if there's an edge between two vertices
                      {
                          //DIGRAPH
                          if (g.outDegree(City(i+1)) == g.outDegree(City(j+1))){        //if two vertices share an edge and each
                              incidenceMatrix[i][edgeNum] = 1;                          //have an outdegree w.r.t such edge then they are both 1
                              incidenceMatrix[j][edgeNum] = 1;
                          }
                          else if (g.outDegree(City(i+1)) && g.inDegree(City(j+1))){    //if an edge is an outdegree at a vertex i
                              incidenceMatrix[i][edgeNum] = 1;                          //and an indegree at another vertex j then i = 1, j = -1
                              incidenceMatrix[j][edgeNum] = -1;
                          }
                          else if (g.inDegree(City(i+1)) && g.outDegree(City(j+1))){    //if an edge is an indegree at a vertex i
                              incidenceMatrix[i][edgeNum] = -1;                         //and an outdegree at a vertex j then i = -1, j = 1
                              incidenceMatrix[j][edgeNum] = 1;
                          }
                          else
                            incidenceMatrix[i][edgeNum] = incidenceMatrix[j][edgeNum] = 0; //if an edge has neither indegree or outdeg
                                                                                           //between two vertices then there is no edge connecting them, thus i = 0, j = 0
                          edgeNum++; //go to next edge                                                      
                          
                          
                      }
                     
                  }
              }
              for(int i = 0; i < s; i++)
              {
                  for(int j = 0; j < g.countEdges(); j++)
                  {
                      cout<<incidenceMatrix[i][j]<< " ";     //print out the values
                  }
                  cout<<endl;
              }
             // End code
             cout<<endl<<endl<<endl;      
          }
          break;          
         case 2: //Connected Components
               cout<<endl;;
               cout<<"Connected Components in "<<argv[0]<<endl<<endl;
               if (g.size() > 0)
               {
                   
                   int* components = new int[g.size()];
                   int totalComponents = getComponents(g, components); 
                   string cityA, cityB;
                   
                   for (int i=1; i <= totalComponents; i++)
                   {
                       cout << "*** Component # " << i << " ***" << endl;
                       
                       for (int j = 1; j <= g.size(); j++)
                       {
                          if(g.isEdge(City(i),City(j)))
                           {
                               cityA =  trim(g.retrieveVertex(City(i)).getLabel());
                               cityB =  trim(g.retrieveVertex(City(j)).getLabel());
                               cout << cityA << endl << cityB << endl;
                           }
                           
                           
                       }
                       
                   }
                   
                   //Add code here to print the list of cities in each component of the graph.
                   //For example:
                   //*** Component # 1 ***
                   //Baton Rouge
                   //Gonzales
                   //Metaire                   
                   //*** Component # 2 ***
                   //Lafayette
                   //Independence
                   //*** Component # 3 ***
                   //Baker
                   //Eunice
                   //Franklin
                   //--------------------------
                   //Number of Components: 3
                   //End code                                     
               }
               else
                   cout<<"The graph has no connected component."<<endl;
            //End add code here
            cout<<endl<<endl<<endl;
            break;
         case 3://All-pairs Shortest-path algorithm
            cout<<"Enter the source vertex: ";
            cin>>i;
            cout<<"Enter the destination vertex: ";  
            cin>>j;
            double wt;
            if (g.isPath(City(i), City(j)))
            {
               double** cost = new double*[(int)g.size()];
               int** path = new int*[(int)g.size()];
               for (k=0; k<g.size(); k++)
               {
                  cost[k] = new double[(int)g.size()];
                  path[k] = new int[(int)g.size()];
               }
               floyd(g,cost,path);
               int initial = i, dest;
               string srcCity = trim(g.retrieveVertex(City(i)).getLabel());             
               string destCity = trim(g.retrieveVertex(City(j)).getLabel());
               cout<<"Shortest route from "<<srcCity<<" to "<<destCity<<":"<<endl;               
               cout<<"========================================================================================="<<endl;
               //Begin Code: Add code here to print each leg of the trip from 
               //            the source to the destination using the format below, 
               //            where the columns are left-aligned and the distances
               //            are displayed to the nearest hundredths.
               //For example:
               //Baton Rouge            ->   Gonzales                  10.20 mi
               //Gonzales               ->   Metairie                   32.00 mi
               //Metaire                ->   New Orleans                7.25 mi
               
              
               
               stack<int> pathStack;
               for(int k = j-1; *path[k] != -1; k = *path[k])
               {
                   
                   pathStack.push(k);
               }
                pathStack.push(i-1);
                int pathStackSize = (int) pathStack.size();
                for(int x = 1; x < pathStackSize; x++)
                {
                    
                    int currentCity = pathStack.top();
                    pathStack.pop();
                    cout  << left << setw(23) << g.retrieveVertex(City(currentCity+1)).getLabel();
                    cout << left << setw(10) << "->";
                    cout << left << setw(14) << g.retrieveVertex(City(pathStack.top()+1)).getLabel();
                    cout.precision(2);
                    cout.setf(ios::fixed);
                    cout << g.retrieveEdge(City(currentCity+1),City(pathStack.top()+1)) << " mi" << endl;
                }


               //End code                         
               cout<<"========================================================================================="<<endl;
               cout<<"Total distance: "<<setprecision(2)<<cost[i-1][j-1]<<" miles."<<endl<<endl;
            }
            else
               cout<<"There is no path."<<endl<<endl;
            cin.ignore(numeric_limits<streamsize>::max(), '\n'); //flush the end-of-line character
            break;
         case 4: //post-order depth-first-search traversal
            cout<<endl;
            cout<<"PostOrder DFS Traversal For The Graph In "<<argv[1]<<endl;
            cout<<"==============================================================="<<endl;
            //invoke the dfsTraverse function   
	    g.dfsTraverse(&display);	
            cout<<"==============================================================="<<endl;
            cout<<endl;
            cout<<endl;
            break;
         case 5: //breadth-first-search traversal
            cout<<endl;
            cout<<"BFS Traversal For The Graph In "<<argv[1]<<endl;
            cout<<"==============================================================="<<endl;
            //invoke the bfsTraverse function        
	    g.bfsTraverse(&display);	
            cout<<"==============================================================="<<endl;
            cout<<endl;
            cout<<endl;
            break;
         case 6: //number of edges
            cout<<endl;
            cout<<"The graph has "<<g.countEdges()<<" edges."<<endl;
            cout<<endl;
            break;
         case 7: //In-degree topological sort (for Project # 4)
            cout<<endl;
            if (topSortInDeg(g,top))
            {
                cout<<"Topological Sorting of The Graph In "<<argv[1]<<endl;
                cout<<"==============================================================="<<endl;
                for (i=1; i<=g.size(); i++)
                {
                    aCity1 = g.retrieveVertex(City(top[i-1]));
                    cout<<left<<setw(3)<<aCity1.getKey()<<" "<<left<<setw(2)<<aCity1.getLabel()<<endl;
                }
                cout<<"==============================================================="<<endl;
            }
            else
                cout<<"No topological ordering possible. The digraph in "<<argv[1]<<" contains a directed cycle."<<endl;
            cout<<endl<<endl;
            break;
         case 8: //primMST (for Project # 4)
            cout<<"Enter the root of the MST: ";
            cin>>j;
            int *mst = new int[(int)g.size()];
            double totalWeight = primMST(g,j,mst);
            string cityName1, cityName2;
            for (i=1; i<=g.size(); i++)
            {
                if (mst[i-1] < 1)
                    cityName1 = "NONE";
                else
                    cityName1 = g.retrieveVertex(City(mst[i-1])).getLabel();
                cityName2 = g.retrieveVertex(City(i)).getLabel();
                cout<<i<<"-"<<trim(cityName2)<<")"<<" parent["<<i<<"] <- "<<mst[i-1]<<" ("<<trim(cityName1)<<")"<<endl;
            }
            cout<<"The weight of the minimum spanning tree/forest is "<<totalWeight<<" miles."<<endl<<endl;
            cin.ignore(numeric_limits<streamsize>::max(), '\n'); //flush the end-of-line character			
            break;
      }
   }
   return 0;
}   

/**
 * Removes leading and trailing whitespace characters from the specified string
 * @param text a string
 * @return the specified string without leading and trailing whitespace characters
 */
string trim(string text)
{
    const auto startIndex = text.find_first_not_of(" \t\r\n");
    if (startIndex == string::npos) text = "";
    const auto endIndex = text.find_last_not_of(" \t\r\n");
    text = text.substr(startIndex, endIndex - startIndex + 1);
    return text;
}

/**
   This function displays a City class object.
   @param c a City class object
   @return none.
*/
void display(const City& c)
{
   cout<<left<<setw(3)<<c.getKey()<<" "<<left<<setw(2)<<c.getLabel()<<endl;
}


/**
 * This function reads a text file formatted as described in the project 
 * description.
 * An instance of a graph to be initialized
 * @param filename the name of the DIMACS formatted graph file.
 *  @return an instance of a graph.
 */
void readGraph(Graph<City>& newGraph, string filename)
{
   fstream inFile;
   char temp;
   string tmp;
   int key,v1, v2, size=0, nEdges=0;
   double weight;
   inFile.open(filename.c_str());
   if (inFile.fail())
   {
      cerr<<"Error opening "<<filename<<endl;
      exit(1);
   }
   while (inFile >> temp)
   {
      if (temp == 'p')
      {
         inFile>>size;
         inFile>>nEdges;
      }
      if (temp == 'c')
      {
         getline(inFile,tmp);
      }
      if (temp == 'n')
      {
         inFile>>key;
         getline(inFile,tmp);
         newGraph.insertVertex(City(key,tmp.c_str()));
      }

      if (temp == 'e')
      {
         inFile>>v1;
         inFile>>v2;
         inFile>>weight;
         newGraph.insertEdge(City(v1),City(v2),weight);
      }
   }
   inFile.close();
}

/**
 * This function displays the menu interface for the weighted
 * digraph application.
 * @return an integer representing the menu option selected.
 */
int menu()
{
   string option;
   do
   {
      cout<<"  BASIC WEIGHTED GRAPH APPLICATION   "<<endl;
      cout<<"====================================="<<endl;
      cout<<"[1] Incidence Matrix (digraph)"<<endl;
      cout<<"[2] Connected Components"<<endl;
      cout<<"[3] All-pairs Shortest Path"<<endl;
      cout<<"[4] Postorder DFS Traversal"<<endl;
      cout<<"[5] BFS Traversal"<<endl;
      cout<<"[6] Number of Edges"<<endl;
      cout<<"[7] Topological Sort Labeling"<<endl;
      cout<<"[8] Prim's Minimum Spanning Tree"<<endl;
      cout<<"[0] Quit"<<endl;
      cout<<"====================================="<<endl;
      cout<<"Select an option: ";
      getline(cin,option);
      option = trim(option);
      if (option < "0" || option > "8")
         cout<<"Invalid option...Try again"<<endl<<endl;
      else
         return atoi(option.c_str());    
   }while(true);
}

/**
 * Find the root vertex of the tree in which the specified vertex is;
 * For use in primMST
 * @param parent the parent implementation of a subtree of a graph
 * @param v a vertex 
 * @return the root of this subtree
 */
int find(int parent[], int v)
{
    while(parent[v] != -1)
    {
        v = parent[v];
    }
    return v;
}
/**
 * This method computes the cost and path matrices using the
 * Floyd all-pairs shortest path algorithm.
 * @param g an instance of a weighted directed graph.
 * @param dist a matrix containing distances between pairs of vertices.
 * @param path a matrix of intermediate vertices along the path between a pair
 * of vertices. 0 indicates that the two vertices are adjacent.
 */
void floyd(const Graph<City>& g, double**& dist, int**& path)
{
    for (int i = 1; i<= g.size(); i++)
    {
        for (int j = 1; j<= g.size(); j++)
        {
            if (g.isEdge(City(i), City(j)))
            {
                path[i][j] = i;
                dist[i][j] = g.retrieveEdge(City(i), City(j));
            }
            else
            {
                path[i][j] = 0;
                dist[i][j] = INFINITY;
            }
        }
    }
    
    for (int k = 1; k<= g.size(); k++)
    {
        for (int i = 1; i<= g.size(); i++)
        {
            for (int j = 1; j<= g.size(); j++)
            {
                if (dist[i][j] > dist[i][k] + dist[k][j])
                {
                    path[i][j] = k;
                    dist[i][j] = dist[i][k] + dist[k][j];
                }
            }
        }
    }
} 

/**
 * This method generates a minimum spanning tree rooted at a given
 * vertex, root. If no such MST exists, then it generates a minimum
 * spanning forest with one of the subtrees at root and with the
 * roots of the other subtrees being the vertex with the smallest
 * key in each  subtree.
 * @param g a weighted digraph
 * @param r root of the minimum spanning tree, when one exists.
 * @param parent the parent implementation of the minimum spanning tree/forest
 * @throw GraphException when the graph is empty
 * @return the weight of such a tree or forest.
 * <pre>
 * Note: If a minimum spanning tree rooted at r is in the graph,
 *       the parent implementation of a minimum spanning tree or forest is
 *       determined. If no such tree exist, the parent implementation
 *       of an MST is thrown. If the tree is empty, an exception
 *       is thrown.
 * </pre> 
 */ 
double  primMST(const Graph<City>& g, int root, int* parent) throw (GraphException)
{
   //Implement this function (for Project # 4)
   /**
    * A local class for entries of the priority queue
    * for bookkeeping purposes when generating the parent
    * implementation of the MST or MSF.
    */
   class Node
   {
      public:
         /**
          * The parent of this node in the MST/MSF
          */		  
         int parent;
         /**
          * This node number - 1...|V|, where |V| is the size of the graph
          */			 
         int id;
         /**
          * The weight on the edge between this node and its parent
          */			 
         double key;
         /**
          * Default (no-args) constructor
          */			 
         Node()
         {
         }
         /**
          * The parameterized constructor
          * @param p the parent of this node
          * @param v this node id
          * @param k the weight of the edge 
          * this node and its parent
          */			 
         Node(int p, int v, double k)
         {
            parent = p;
            id = v;
            key = k;
         }           
   };
   //Define a (greater than) lambda function for a node comparator then
   //use the function to instantiate a priority queue. The comparator will be
   //used to compare entries of the priority queue as the MST/MSF is generated.
   auto greaterThan = [](const Node& n1,const Node& n2)
   {  
        if (n1.key > n2.key)
           return true;
        if (n1.key < n2.key)
           return false;
        if (n1.id > n2.id)
           return true;
        if (n1.id < n2.id)
           return false;

        return false;
    };
    priority_queue<Node, vector<Node>, decltype(greaterThan)> nQueue(greaterThan);
   
   
    double totalweight = 0;
    bool intree [g.size()];
    int key [g.size()];
    
    for(int i = 1; i<= g.size();i++)
    {   
        parent[i-1]= -1;
        intree[i-1] = false;
        for(int j = i+1; j<=g.size(); j++)
        {
            if (g.isEdge(City(i),City(j)))
            {
                Node nq;
                nq.key = g.retrieveEdge(i,j);
                nq.parent = j-1;
                nq.id = i-1;
                nQueue.push(nq);
            }
        }
    }
    
    
    while(!nQueue.empty())
    {
        Node n = nQueue.top();
        nQueue.pop();
        
        if(intree[n.id] && intree[n.parent])
        {
            if(find(parent, n.parent) != find(parent, n.id))
            {
                int temp = n.id;
                int temp2 = n.parent;
                int temp3 = parent[temp2];
                while(temp3 != -1)
                {
                    parent[temp2] = temp;
                    temp = temp2;
                    temp2 = temp3;
                    temp3 = parent[temp2];
                }
                parent[temp2] = temp;
                totalweight += n.key;
            }
            
        }
        else if(!intree[n.id] && !intree[n.parent])
        {
            intree[n.id] = intree[n.parent] = true;
            parent[n.parent] = n.id;
            totalweight += n.key;
        }
        else if(intree[n.id] && !intree[n.parent])
        {
            intree[n.parent] =  true;
            parent[n.parent] = n.id;
            totalweight += n.key;
        }
        else
        {
            intree[n.id] = true;
            parent[n.id] = n.parent;
            totalweight += n.key;
        }
        
    }
    
    for(int i = 0; i < g.size(); i++)
    {
        if(parent[i] != -1)
            parent[i]++;
    }
    return totalweight;

}

/**
   an auxilliary function for the topoSort and getComponents method.
   @param g a weighted directed graph
   @param v current vertex
   @param seen a 1-D boolean matrix of vertices that
          have been marked.
   @param linearOrder a 1-D array containing the
          topologically sorted list.
   @param index current index.
*/
 void dfs(const Graph<City>& g, int v, bool seen[], int linearOrder[], int& index)
 {
     seen[v-1] =true;
     for(int i = 1; i <= (int)g.size(); i++)
     {
         if(g.isEdge(City(v), City(i)) && !seen[i-1])
         {
             dfs(g, i, seen, linearOrder, index);
         }
     }
     linearOrder[index] = v;
     index--;
 }


/**
 * Generates a topological labeling of the specified digraph by repeatedly
 * selecting a vertex with 0 in-degree and then removing the vertex and all
 * its incident edges from the graph. The graph is explored in lexicographical
 * order when adding a new vertex to the topological ordering.
 * @param g a digraph
 * @param linearOrder the topological ordering of the vertices
 * @return true if a topological ordering of the vertices of the specified digrap
 * exists; otherwise, false.
 */
bool topSortInDeg(const Graph<City> &g, int*& linearOrder)
{
   
    int count = (int)g.size();
    // Mark all the vertices as not visited
    bool *visited = new bool[count];
    
    
    for (int i = 0; i < g.size(); i++)
    {
        visited[i] = false;
        linearOrder[i] = 0;
    }
    
    for (int j = 0; j < g.size(); j++)
    {
        if (!visited[j])
        {
            dfs(g, j, visited, linearOrder, count);
        }
    }
    
    return true;   
 
}

/**
 * Generates the connected components of this graph
 * @param g a graph of city objects
 * @param components an associative array of city
 * key to component number: if components[i] = k, then
 * city i+1 is in component k.
 * @return the number of components in this graph
 */
int getComponents(const Graph<City>& g, int*& components)
{
    int count = (int)g.size();
    int compCount = 0;
    bool seen [count];
    
    for (int i = 0; i < g.size(); i++) //iterate on all vertices
    {
        seen[i] = false; //mark all as unseen
        components[i] = i; //fill array with vertices
    }
    for(int j =1;j <= (int)g.size(); j++)
     {
         if(!g.isEdge(City(j-1),City(j)))
         {
             compCount++;   
         }
         else
         {
             dfs(g, j, seen, components, count);
         }
     }
    
    return compCount;

}





