#include <fstream>
#include <string>
#include <cstring>
#include <sstream>
#include <vector>
#include <stdexcept>
#include <list>
#include "Polynomial.h"
#include "Heap.h"
#include "Heap.cpp"

/**
 * A program that executes a set of insert and remove instructions on a 
 * heap, using Polynomial objects, and displays a trace of the instructions
 * as they are executed.<br>
 * csc 3102 Section 1<br>
 * Programming Project # 1<br>
 * @author Duncan, Landon Weber
 * @since 02-20-2018
 * @see Heap, Polynomial
 */

using namespace std;

int main(int argc, char** argv) 
{
    Heap<string> heap;                  //declare heap
    double* coeffs = new double;        
    double doubleNum;
    ifstream file(argv[1]);             //read in file from first argument
    
   
    
    if (file.is_open() && !file.eof()){  //if file is open and not at the end
        string line, command;           // line and command string variables
        istringstream sst;               //stringstream to store values and parse   
        
        while (file){                   //while file is open
            getline(file, line);        //get line of data
            sst.str(line);              //store line into stringstream
            sst >> command;             //get the first string value in the line
            
            if (command == "insert"){    
                int deg;                
                sst >> deg;                         //get the first int val and store into deg variable
                for (int i = 0; i <= deg; i++){     //loop through rest of line while ONLY storing double numbers (coefficients)
                    sst >> doubleNum;
                    coeffs[i] = doubleNum;          //put the double values in coeff array
                }     
                Polynomial poly(coeffs, deg);       //create polynomial instance
            
                heap.insert(poly.str());            //insert into heap
                cout << "Inserted: " << poly.str() << endl; //display inserted polynomial
            }
            else if(command == "remove")                    //test if the command is remove
                cout <<  "Removed: " << heap.remove() << endl;   //display removed heap item
                     
        }
    }
    return 0;
}


