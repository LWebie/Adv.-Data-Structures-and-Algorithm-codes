/**
 * Implements the basic operations of the polynomial
 * Course: CSC3102.01
 * Programming Project #1
 * Instructor: Dr. Duncan
 * @author Duncan, Landon Weber
 * @since 02-20-2018
 */
#include "Polynomial.h"
#include <sstream>
#include "Heap.h"
#include <math.h>
#include <iostream>
#include <string>
#include <cstdlib>
#include <iomanip>
#include <chrono>
#include <stdexcept>
#include <vector>

bool operator==(const Polynomial& p1, const Polynomial& p2)
{
    return compare(p1,p2) == 0;
}
 
bool operator!=(const Polynomial& p1, const Polynomial& p2)
{
    return compare(p1,p2) != 0;
}

bool operator>(const Polynomial& p1, const Polynomial& p2)
{
    return compare(p1,p2) > 0;
}

bool operator<(const Polynomial& p1, const Polynomial& p2)
{
    return compare(p1,p2) < 0;
}

bool operator>=(const Polynomial& p1, const Polynomial& p2)
{
    return compare(p1,p2) >= 0;
}

bool operator<=(const Polynomial& p1, const Polynomial& p2)
{
    return compare(p1,p2) <= 0;
}
    
int compare(const Polynomial& p1, const Polynomial& p2)
{
    int testValue = 20;
    int p1_Eval = p1.hornerEval(testValue);
    int p2_Eval = p2.hornerEval(testValue);
    if (p1_Eval != p2_Eval)
        return -1;
    else
        return 0;   
}

Polynomial::Polynomial()
{
    deg = 0;                              //degree is 0
    coeffs = new double[deg];           //allocate and create new coeff
    coeffs[0] = 0;                        //set the element to zero.
   
}

Polynomial::Polynomial(const double* c, int d) throw (invalid_argument)
{
    bool invalid_argument = NULL;           //set invalid argument to false
    if (d < 0)                              //if d is < 0 we have an invalid argument
        invalid_argument = true;
    else if (c[0] == 0 && d > 0)            //if both c[0] && d > 0 we have an invalid argument
        invalid_argument = true;
    
    deg = d;                               //set deg equal to passed in value
    coeffs = new double[deg + 1];                            //set coeff equal to passed in array address
    for (int i = 0; i <= deg; i++)         //place coefficients in the coeffs array
        coeffs[i] = c[i];
}

Polynomial::Polynomial(const Polynomial& other) //Copy constructor
{
   deg = other.deg;
   coeffs = new double[deg];
   for (int i = 0; i <= deg; i++)
        coeffs[i] = other.coeffs[i];
}

Polynomial::Polynomial(Polynomial&& other) noexcept //move constructor
{
    coeffs = other.coeffs;
    other.coeffs = nullptr;
    deg = other.deg;
    
}

Polynomial& Polynomial::operator =(const Polynomial& other) //Overloaded copy assignment operator
{
    
    if (&other != this)
    {
      delete [] coeffs;  
      deg = other.deg;
      coeffs = new double[deg];
      for (int i = 0; i <= deg; i++)
	coeffs[i] = other.coeffs[i];
    }

return *this;
    
}     


Polynomial& Polynomial::operator= (Polynomial&& other) noexcept
{
  
        
        delete[] coeffs;     // unallocate the buffer we currently own
        coeffs = other.coeffs;    // take ownership of other's buffer
        other.coeffs = nullptr;  // have other release ownership of the buffer
        deg = other.deg; 

        
        return *this;
}

Polynomial::~Polynomial() noexcept
{
    
}

double Polynomial::hornerEval(double x) const
{
    double sum = 0.0;                               //initialize sum to 0
    for(int i = 0; i <= deg; i++) 
        sum = sum * x + *(coeffs + i);              //multiply sum by x and coeff[i]
    return sum; 
}

double Polynomial::naiveEval(double x) const
{
   double sum = 0.0;                               //initialize sum to 0
   for(int i = 0; i <= deg; i++) {                 //exponent loop
        double m = *(coeffs + i);
        for(int j = 0; j < deg - i; j++)          //sum loop
            m = m * x;                              //multiply by x
        sum = sum + m;                              //add running sum to calculated value
    }
   return sum; // return sum final value
}

int Polynomial::degree() const
{
    return deg;  
}

string Polynomial::str() const
{
    string s;                             //declare string to store
    stringstream ss;                      //initialize stringstream
    int degreeCount = this->deg;                //create a copy degree value
    if (deg == 0){                        //return coeff value entered if deg = 0
        ss << this->coeffs[0];
        s = ss.str();
        return s;
    }       
    if (coeffs[0] > 1 && deg != 1){      //Test first coeffs value and degree
         ss << fixed << setprecision(2) << coeffs[0] << "x^" << deg;
         s = ss.str();
         degreeCount--;                   //decrease degree by 1
    }
    if (coeffs[0] < 1 && deg != 1){      //Test first coeffs value and degree
         ss << fixed << setprecision(2) << coeffs[0] << "x^" << deg;
         s = ss.str();
         degreeCount--;                   //decrease degree by 1
    }
    if (coeffs[0] == 1 && deg == 1){
        ss << fixed << setprecision(2) << "x";
        s = ss.str();
        degreeCount--;
    }
    
    for (int i = 1; i <= deg-1; i++){        //loop through until the second to last coeffs value
       ss << fixed << setprecision(2);
        if(this->coeffs[i] > 0)                 //addition sign if coeffs value is positive
            ss << "+";
        if (this->coeffs[i] >= 1 || this->coeffs[i] <= -1){    //begin nested if, if coeffs value is neither 1, -1
            if (this->coeffs[i] != 0){                    //continue is coeffs value is not zero
                if (this->coeffs[i] != 1 && this->coeffs[i] != -1){    //display coeffs value and variable x if not equal to -1 or 1
                       ss << this->coeffs[i] << "x";
                }
                else{
                       ss << "x";
                }
                if (degreeCount != 1 && degreeCount != 0) //if degree is not 1 or 0, display it
                        ss << "^" << degreeCount;          
            }
        }
        
        degreeCount--;          //decrement degree for use on the next coeffs value
        s = ss.str();           // set the string equal to the values pushed onto the stringstream
    }
  
  
    
    if (this->coeffs[this->deg] != 0){      //Test last value in coeffs array
        if (this->coeffs[this->deg] > 0)    //if positive value add
            ss << "+";
        else
            ss << "-";
         ss << fixed << setprecision(2) << this->coeffs[this->deg]; //display final value
         s = ss.str();
        
    }
    
    return s;   
}



