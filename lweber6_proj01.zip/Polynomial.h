/**
 * Describes a univariate polynomial and basic operations
 * on it.
 * Course: CSC3102.01
 * Programming Project #1
 * Instructor: Dr. Duncan
 * @author Duncan, Landon Weber
 * @since 02-20-2018
 */

#ifndef POLYNOMIAL_H
#define	POLYNOMIAL_H
#include "Heap.h"
#include <string>
#include <sstream>
#include <vector>
using namespace std;

class Polynomial
{
private:
    /**
     * An array of coefficients of this polynomial arranged in order of 
     * descending powers.
     */
    double *coeffs;
    /**
     * The degree of this polynomial [length of coeffs - 1]
     */
    int deg;
    /**
     * Determines whether two polynomials are equal.
     * @param p1 a polynomial used as the left-hand operand
     * @param p2 a polynomial used as the right-hand operand
     * @return true when the specified polynomials are equal;
     * otherwise, false
     */
    friend bool operator==(const Polynomial& p1, const Polynomial& p2);
    /**
     * Determines whether two polynomials are unequal.
     * @param p1 a polynomial used as the left-hand operand
     * @param p2 a polynomial used as the right-hand operand
     * @return true when the specified polynomials are unequal;
     * otherwise, false
     */    
    friend bool operator!=(const Polynomial& p1, const Polynomial& p2);
    /**
     * Determines whether one polynomial has a faster asymptotic
     * growth rate than another
     * @param p1 a polynomial used as the left-hand operand
     * @param p2 a polynomial used as the right-hand operand
     * @return true when the left-hand operand has a faster asymptotic
     * growth rate than the right-hand operand; otherwise, false
     */    
    friend bool operator>(const Polynomial& p1, const Polynomial& p2);
    /**
     * Determines whether one polynomial has a slower asymptotic
     * growth rate than another
     * @param p1 a polynomial used as the left-hand operand
     * @param p2 a polynomial used as the right-hand operand
     * @return true when the left-hand operand has a slower asymptotic
     * growth rate than the right-hand operand; otherwise, false
     */        
    friend bool operator<(const Polynomial& p1, const Polynomial& p2);
    /**
     * Determines whether one polynomial has the same or faster asymptotic
     * growth rate than another
     * @param p1 a polynomial used as the left-hand operand
     * @param p2 a polynomial used as the right-hand operand
     * @return true when the left-hand operand has the same or faster asymptotic
     * growth rate than the right-hand operand; otherwise, false
     */    
    friend bool operator>=(const Polynomial& p1, const Polynomial& p2);
    /**
     * Determines whether one polynomial has the same or slower asymptotic
     * growth rate than another
     * @param p1 a polynomial used as the left-hand operand
     * @param p2 a polynomial used as the right-hand operand
     * @return true when the left-hand operand has the same or slower asymptotic
     * growth rate than the right-hand operand; otherwise, false
     */    
    friend bool operator<=(const Polynomial& p1, const Polynomial& p2);
    
    /**
     * A trichotomous function that compares the growth rates of
     * the specified polynomials.
     * @param p1 a polynomial used as the left-hand operand
     * @param p2 a polynomial used as the right-hand operand
     * @return -1 if p1 has a slower growth rate than p2;
     * 0, if they have the same growth rate; otherwise, -1
     */
    friend int compare(const Polynomial& p1, const Polynomial& p2);
    
public:
    /**
     * Creates the polynomial 0.
     */
    Polynomial();
    /**
     * Creates a polynomial with the specified coefficients.
     * @param c the coefficients of this polynomial in order of descending powers
     * @param d the degree of this polynomial
	 * @throw invalid_argument exception when 
	 * 1. d is negative or 
	 * 2. c[0] = 0 and d > 0
     */
    Polynomial(const double* c, int d) throw (invalid_argument);

    /**
     * (Copy constructor) Creates a copy of the specified polynomial.
     * @param other constant reference to a polynomial
     */	
    Polynomial (const Polynomial& other);
    
    /**
     * (Move constructor) sets the coefficient of this polynomial to
     * point to the coefficient of the specified polynomial and then set the
     * coefficient of the specified array to null. Additionally,
     * it sets the degree of the new polynomial so that it is the
     * same as the degree of the specified parameter.
     * @param other a reference to a reference to a polynomial
     */	
    Polynomial (Polynomial&& other) noexcept;    
	
    /**
     * (Overloaded The copy assignment operator) Assigns one polynomial to the
     * the other so that the two polynomials are equal.
     * @param other constant reference to a polynomial
     * @return a reference to a polynomial that is equal to the specified polynomial
     */		
    Polynomial & operator= (const Polynomial& other);	

    /**
     * (Overloaded move assignment operator) deallocates the coefficient of this
     * polynomial, then sets its coefficient to point to the coefficient of the 
     * specified polynomial and sets the coefficient of the specified polynomial to null.
     * Additionally, it sets the degree of this polynomial so that it is the same as
     * the degree of the specified parameter.
     * @param other a reference to a reference to a polynomial
     * @return a reference to a polynomial that is equal to what the specified polynomial
     * was.
     */		
    Polynomial & operator= (Polynomial&& other) noexcept;	    
    
    /**
     * (destructor) deallocates the array allocated for the coefficients of this
     * polynomial
     */	 
    ~Polynomial() noexcept;
    
    /**
     * Evaluates this polynomial at the specified point using the
     * Horner's evaluation method.
     * @param x the point at which this polynomial is to be evaluated
     * @return the value of the polynomial at the specified point
     */
    double hornerEval(double x) const;
    
    /**
     * Evaluates this polynomial at the specified point using a
     * naive evaluation method.
     * @param x the point at which this polynomial is to be evaluated.
     * @return the value of the polynomial at the specified point.
     */
    double naiveEval(double x) const;
    
    /**
     * Gives the degree of this polynomial.
     * @return the degree of this polynomial
     */
    int degree() const;
    
    /**
     * Gives a string representation of this polynomial in descending powers
     * in standard form where zero terms, coeffients 1 and -1, and exponent
     * 1 are not displayed.
     * <pre>
     * Note: Rules for Representing a Polynomial in Normalized Form:
     * 1. If the degree of the polynomial is 0, return the number.
     * 2. Generate the string representation of the highest order term 
     *    without using 1, -1 as a coefficient  or 1 as an exponent.
     * 3. Generate and concatenate the string representations of all other,
     *    but the last two, terms begining from the second highest order term 
     *    without the use of 1 and -1 as coefficients and without concatenating
     *    a zero term.
     * 4. If the degree of the polynomial is greater than 1 and its linear term 
     *    is non-zero, generate and concatenate the linear term but without the 
     *    use of 1 and -1 as its coefficient and 1 as its exponent.
     * 5. Finally, concatenate the constant term, the lowest order term, if it 
     *    is non-zero.	 
     *    eg: [3, 0, -1, 0, 1, 1, 0] -> 3x^6 - x^4 + x^2 + x
     *        [-1, 0, 3, 0, -1, 1] -> -x^5 + 3x^3 - x + 1
     * </pre>
     * @return a string representation of this polynomial
     */
   string str() const;  
};
#endif	/* POLYNOMIAL_H */



