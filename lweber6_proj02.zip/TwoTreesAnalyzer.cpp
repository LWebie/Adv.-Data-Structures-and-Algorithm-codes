/**
 * Performs insertions and searches, using the same data set,on a binary search
 * tree and an AVL tree to compare the empirically compare the performance of
 * these operations on the trees.
 * @author Duncan, Landon Weber
 * @SEE AVLTree.cpp,BSTree.cpp, WordStat.h
 * @since 03-09-2018
 */
#include <iostream>
#include <cstdlib>
#include <stdexcept>
#include <iomanip>
#include <fstream>
#include <sstream>
#include <string>
#include <algorithm>
#include <functional>
#include <iterator>
#include <initializer_list>
#include <vector>
#include <array>
#include <queue>
#include "AVLTree.cpp"
#include "BSTree.cpp"

using namespace std;

typedef void (*FuncType)(const string&);

/**
 * Converts the specified string to uppercase
 * @param w a string
 * @return the uppercase version of the specified string
 */
string toUpper(string w)
{
   transform(w.begin(), w.end(),w.begin(),::toupper);
   return w;
}

/**
 * A lambda function to apply to the data in each node of a tree
 * @param word an item in the tree
 */
void printWord(const string& word)
{
    cout<<left<<setw(20)<<word<<endl;
}

int main(int argc, char** argv) 
{
    if (argc != 2){    //if unable to get file as argument                     
        cout << "Invalid number of arguments!" << endl;
        return 1;
    }
    
    BSTree<string> bsTree; //string BST
    AVLTree<string> avlTree;    //string AVL
    fstream inFile;  //fstream to store our file
    
    inFile.open(argv[1]);   //open the file that is specified in second argument
    if (inFile.fail()){     //if file can't open
        cout << "ERROR: Couldn't open file " << argv[1] << endl;
        exit(1);
    }
    
    string command, line;          //command and line string variables
    istringstream sst;             //stringstream to store values
    
    while(inFile){                 //while file is open
        getline(inFile, line);     //get line of data
        sst.str(line);             //store into stringstream
        sst >> command;            //get first string value in the line
        
        if (command == "insert"){  //if first string is insert
            string word;            //string variable word
            sst >> word;            //get the next string value and store into word
            avlTree.insert(toUpper(word)); //get uppercase word and insert into AVL tree
            bsTree.insert(toUpper(word));  //get uppercase word and insert into BST
            cout << "inserted: " << toUpper(word) << " in the AVL\n";
            cout << "inserted: " << toUpper(word) << " in the BST\n";
            cout << "Type: size\t" << "height\t" << "complete? " << "balanced?\n";
            cout << "AVL:  " << avlTree.size() << "\t\t" << avlTree.height() << "\t"; //display size and height
            if (avlTree.isComplete()) //if tree is complete
                cout << "true\t";
            else                     //if tree is not complete
                cout << "false\t";
            cout <<"true\n";
            cout << "BST:  " << bsTree.size() << "\t\t" << bsTree.height() << "\t"; //display size and height
            if (bsTree.isComplete()) //if tree is complete
                cout << "true\t";
            else
                cout << "false\t";  //if tree is not complete
            if (bsTree.isBalanced())    //if tree is balanced
                cout << "true\t";
            else                        //if tree is not balanced
                cout << "false\t";
            
            cout << endl << endl;
        }
        if (command == "remove"){   //if first string is remove
           
            string word;            //string variable word
            sst >> word;            //get the next string value and store into word
            avlTree.remove(toUpper(word));   //remove specified word from AVL Tree
            bsTree.remove(toUpper(word));
            cout << "removed: " << toUpper(word) << " from a depth of " << avlTree.depth(toUpper(word)) << " in the AVL\n";
            cout << "removed: " << toUpper(word) << " from a depth of " << bsTree.depth(toUpper(word)) <<  " in the BST\n";
            cout << "Type: size\t" << "height\t" << "complete? " << "balanced?\n";
            cout << "AVL:  " << avlTree.size() << "\t\t" << avlTree.height() << "\t";   //display size and height
            if (avlTree.isComplete())   //if tree is complete
                cout << "true\t";
            else
                cout <<"false\t";       //if tree is not complete
            cout << "true\n";
            cout << "BST:  " << bsTree.size() << "\t\t" << bsTree.height() << "\t";     //display size and height
            if (bsTree.isComplete())    //if tree is complete
                cout << "true\t";
            else                        //if tree is not complete
                cout <<"false\t";
            if (bsTree.isBalanced())    //if tree is balanced
                cout << "true\t";
            else                        //if tree is not balanced
                cout << "false\t";
            
            cout << endl << endl;
            
        }
        if (command == "traverse"){     //if first string is traverse
            int avlCount = 0;           //avl word count
            int bstCount = 0;           //bst word count
            string word;                //string variable word
            sst >> word;                //get the next string value and store into word
            if (word == "-level"){      //if word is -level
                cout << "AVL (level-order): \n";
                avlTree.levelTraverse(&printWord); //level traverse tree and print each word
                avlCount = avlTree.size();         //get tree size (word count)
                cout << "--------------------------------------\n";
                cout << "word count: " << avlCount << endl << endl;   //display word count
                cout << "BST (level-order): \n";
                bsTree.levelTraverse(&printWord);   //level traverse tree and print each word
                bstCount = bsTree.size();           //get tree size (word count)
                cout << "--------------------------------------\n";
                cout << "word count: " << bstCount << endl << endl;   //display word count
                    
            }
            
            if (command == "-order"){ //if word is -order
                cout << "AVL (in-order): \n";
                avlTree.traverse(&printWord); //in order traverse tree and print each word
                avlCount = avlTree.size();      //get tree size (word count)
                cout << "--------------------------------------\n";
                cout << "word count: " << avlCount << endl << endl; //display word count
                cout << "BST (in-order): \n";
                bsTree.traverse(&printWord);    //in order traverse tree and print each word
                bstCount = bsTree.size();        //get tree size (word count)
                cout << "--------------------------------------\n";
                cout << "word count: " << bstCount << endl << endl; //display word count
            
            }           
        }
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    return 0;
}

